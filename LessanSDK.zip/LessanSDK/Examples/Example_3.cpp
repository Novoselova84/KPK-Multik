# include "TXLib.h"

const int SleepTime = 10;

void DrawSun (int x, int y, double sizeX, double sizeY, COLORREF sunColor, COLORREF glassesColor, COLORREF eyesColor,
              COLORREF mouthColor, COLORREF hatColor, double hello, double surprise, double anger, double newHat, double ray);

int main ()
    {
    txBegin ();

    txCreateWindow (1400, 800);
    txClear ();

    int t = 0;
    while (t <= 300)
        {
        txSetFillColor (TX_WHITE);
        txClear ();

        DrawSun (600, 340, 1.2, 1.2, RGB (255, 255, 0), RGB (0, 238, 238), RGB (66, 132, 0),
                 TX_WHITE, RGB (128, 0, 255), (t/30)%2 * 1, (t/40)%2 * 1, 0, (t/30)%2 * 1, (t/20)%2 * 1);

        txSleep (SleepTime);

        t ++ ;
        }

    txEnd ();
    }

void DrawSun (int x, int y, double sizeX, double sizeY, COLORREF sunColor, COLORREF glassesColor, COLORREF eyesColor,
              COLORREF mouthColor, COLORREF hatColor, double hello, double surprise, double anger, double newHat, double ray)
    {
    txSetColor (sunColor, 2);

    if (anger >= 1)
       txSetFillColor (TX_RED);
    else
       txSetFillColor (sunColor);

    txCircle (x, y , 100*sizeX);
    txLine   (x - (190 + ray*35)*sizeX, y -  (40 + ray*35)*sizeY, x - (100 + ray*35)*sizeX, y -  (20 + ray*35)*sizeY);
    txLine   (x - (200 + ray*10)*sizeX, y,                        x - (100 + ray*10)*sizeX, y);
    txLine   (x - (200 + ray*35)*sizeX, y +  (70 + ray*35)*sizeY, x -  (95 + ray*35)*sizeX, y +  (30 + ray*35)*sizeY);
    txLine   (x - (180 + ray*10)*sizeX, y + (140 + ray*10)*sizeY, x -  (80 + ray*10)*sizeX, y +  (60 + ray*10)*sizeY);
    txLine   (x - (150 + ray*35)*sizeX, y + (210 + ray*35)*sizeY, x -  (60 + ray*35)*sizeX, y +  (80 + ray*35)*sizeY);
    txLine   (x - (100 + ray*10)*sizeX, y + (270 + ray*10)*sizeY, x -  (30 + ray*10)*sizeX, y +  (95 + ray*10)*sizeY);
    txLine   (x -   20          *sizeX, y + (270 + ray*35)*sizeY, x -   15          *sizeX, y + (100 + ray*35)*sizeY);
    txLine   (x +   50          *sizeX, y + (250 + ray*10)*sizeY, x +   20          *sizeX, y +  (95 + ray*10)*sizeY);
    txLine   (x + (200 + ray*35)*sizeX, y -  (40 + ray*35)*sizeY, x + (100 + ray*35)*sizeX, y -  (20 + ray*35)*sizeY);
    txLine   (x + (205 + ray*10)*sizeX, y,                        x + (105 + ray*10)*sizeX, y);
    txLine   (x + (205 + ray*35)*sizeX, y +   70          *sizeY, x + (100 + ray*35)*sizeX, y +   30          *sizeY);
    txLine   (x + (220 + ray*10)*sizeX, y +  140          *sizeY, x +  (80 + ray*10)*sizeX, y +   60          *sizeY);
    txLine   (x + (190 + ray*35)*sizeX, y +  210          *sizeY, x +  (60 + ray*35)*sizeX, y +   80          *sizeY);
    txLine   (x +  140          *sizeX, y + (230 + ray*10)*sizeY, x +  (40 + ray*10)*sizeX, y +  (90 + ray*10)*sizeY);

    txSetColor     (glassesColor, 4);
    txSetFillColor (glassesColor);
    txCircle (x - 30*sizeX, y - 10*sizeY, 25*sizeX);
    txCircle (x + 30*sizeX, y - 10*sizeY, 25*sizeX);
    txLine   (x - 95*sizeX, y - 35*sizeY, x - 45*sizeX, y - 10*sizeY);
    txLine   (x + 30*sizeX, y -  5*sizeY, x + 90*sizeX, y - 35*sizeY);
    txLine   (x - 10*sizeX, y - 10*sizeY, x + 10*sizeX, y - 10*sizeY);

    txSetFillColor (eyesColor);
    txCircle (x - 30*sizeX, y -  10*sizeY, (10 + surprise*5)*sizeX);
    txCircle (x + 30*sizeX, y -  10*sizeY, (10 + surprise*5)*sizeX);

    if (anger >= 1)
        {
        txSetColor   (RGB (54, 237, 50), 3);
        txSelectFont ("Arial", 30);
        txDrawText   (x - (35 + anger*10)*sizeX, y + 30*sizeY, x + (35 + anger*10)*sizeX, y + 70*sizeY, "NO");
        }
    else
        {
        txSetColor     (TX_LIGHTGRAY, 3);
        txSetFillColor (mouthColor);
        txArc   (x - (35 + surprise*10)*sizeX, y + 20*sizeY, x + (35 + surprise*10)*sizeX, y + (55 + surprise*10)*sizeY, (sizeY >= 0)? 180:0, 180);
        txChord (x - (35 + surprise*10)*sizeX, y + 20*sizeY, x + (35 + surprise*10)*sizeX, y + (55 + surprise*10)*sizeY, (sizeY >= 0)? 180:0, 180);
        }

    if (newHat > 0)
        {
        txSetColor     (RGB (54, 237, 50), 3);
        txSetFillColor (RGB (54, 237, 50));
        txEllipse   (x - 100*sizeX, y - (100 + hello*60)*sizeY, x + 100*sizeX, y - (50 + hello*60)*sizeY);
        txArc       (x -  60*sizeX, y - (140 + hello*60)*sizeY, x +  60*sizeX, y - (50 + hello*60)*sizeY, 0, 180);
        txRectangle (x -  60*sizeX, y - (140 + hello*60)*sizeY, x +  60*sizeX, y - (80 + hello*60)*sizeY);
        }
    else
        {
        txSetColor     (hatColor, 3);
        txSetFillColor (hatColor);
        txEllipse      (x - 100*sizeX, y - (100 + hello*60)*sizeY, x + 100*sizeX, y - (50 + hello*60)*sizeY);
        txArc          (x -  60*sizeX, y - (140 + hello*60)*sizeY, x +  60*sizeX, y - (50 + hello*60)*sizeY, 0, 180);
        txRectangle    (x -  60*sizeX, y - (140 + hello*60)*sizeY, x +  60*sizeX, y - (80 + hello*60)*sizeY);
        }
    }
