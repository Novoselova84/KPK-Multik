# include "TXLib.h"

const int SleepTime = 10;

void DrawBigCloud (int x, int y, double sizeX, double sizeY, COLORREF bigCloudColor, double darkBigCloud, double hit);

int main ()
    {
    txBegin ();

    txCreateWindow (1400, 800);
    txClear ();

    int t = 0;
    while (t <= 300)
        {
        txSetFillColor (TX_WHITE);
        txClear ();

        DrawBigCloud ( 100 + t/2,  50, 1,   1, TX_LIGHTGRAY, (t/30)%2 * 1, (t/30)%2 * 1);

        txSleep (SleepTime);

        t ++ ;
        }

    txEnd ();

    return 0;
    }

void DrawBigCloud (int x, int y, double sizeX, double sizeY, COLORREF bigCloudColor, double darkBigCloud, double hit)
    {
    if (darkBigCloud < 1)
        {
        txSetColor (bigCloudColor, 25);
        txArc (x,             y,            x + 100*sizeX, y + 30*sizeY,   0, 180);
        txArc (x + 100*sizeX, y,            x + 250*sizeX, y + 40*sizeY,   0, 180);
        txArc (x,             y,            x +  50*sizeX, y + 30*sizeY, 180, 180);
        txArc (x +  50*sizeX, y,            x + 150*sizeX, y + 30*sizeY, 180, 180);
        txArc (x + 150*sizeX, y + 10*sizeY, x + 250*sizeX, y + 30*sizeY, 180, 180);
        }
    else
        {
        txSetColor (RGB (97, 97, 97), 40);
        txArc (x,             y,            x + 100*sizeX, y + 30*sizeY,   0, 180);
        txArc (x + 100*sizeX, y,            x + 250*sizeX, y + 40*sizeY,   0, 180);
        txArc (x,             y,            x +  50*sizeX, y + 30*sizeY, 180, 180);
        txArc (x +  50*sizeX, y,            x + 150*sizeX, y + 30*sizeY, 180, 180);
        txArc (x + 150*sizeX, y + 10*sizeY, x + 250*sizeX, y + 30*sizeY, 180, 180);

        txSetColor     (TX_GRAY, 2);
        txSetFillColor (RGB (255, 38, 38));
        POINT lightning [7] = {{ROUND (x + 100*sizeX), ROUND (y +  (40 + hit*50)*sizeY)},
                               {ROUND (x + 110*sizeX), ROUND (y +  (40 + hit*50)*sizeY)},
                               {ROUND (x + 105*sizeX), ROUND (y +  (60 + hit*50)*sizeY)},
                               {ROUND (x + 115*sizeX), ROUND (y +  (60 + hit*50)*sizeY)},
                               {ROUND (x +  95*sizeX), ROUND (y + (140 + hit*50)*sizeY)},
                               {ROUND (x + 105*sizeX), ROUND (y +  (70 + hit*50)*sizeY)},
                               {ROUND (x +  95*sizeX), ROUND (y +  (70 + hit*50)*sizeY)}};
        txPolygon (lightning, 7);

        POINT lightningSmall [7] = {{ROUND (x + 145*sizeX), ROUND (y +  30*sizeY)},
                                    {ROUND (x + 155*sizeX), ROUND (y +  30*sizeY)},
                                    {ROUND (x + 150*sizeX), ROUND (y +  50*sizeY)},
                                    {ROUND (x + 160*sizeX), ROUND (y +  50*sizeY)},
                                    {ROUND (x + 140*sizeX), ROUND (y + 110*sizeY)},
                                    {ROUND (x + 150*sizeX), ROUND (y +  60*sizeY)},
                                    {ROUND (x + 140*sizeX), ROUND (y +  60*sizeY)}};
        txPolygon (lightningSmall, 7);
        }
    }
