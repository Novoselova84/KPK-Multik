# include "TXLib.h"

void DrawTV ();

int main ()
    {
    txCreateWindow (1400, 800);
    txClear ();

    DrawTV ();

    return 0;
    }

void DrawTV ()
    {
    txSetColor     (RGB (112, 112, 112), 55);
    txSetFillColor (RGB (192, 244, 245));
    txRectangle    (10, 10, 1400, 800);

    txSetFillColor (RGB (112, 112, 112));
    txRectangle    (1210, 10, 1390, 790);

    txSetColor     (RGB (255, 0, 0));
    txSetFillColor (RGB (255, 0, 0));
    txRectangle    (1260, 50, 1310, 70);

    txSetColor     (RGB (0, 0, 255));
    txSetFillColor (RGB (0, 0, 255));
    txRectangle    (1310, 50, 1360, 70);

    txSetColor     (RGB (255, 255, 0));
    txSetFillColor (RGB (255, 255, 0));
    txCircle       (1310, 200, 30);

    txSetColor     (RGB (0, 255, 0));
    txSetFillColor (RGB (0, 255, 0));
    txCircle       (1310, 280, 30);

    txSetColor     (RGB (0, 0, 128));
    txSetFillColor (RGB (0, 0, 128));
    txCircle       (1310, 360, 30);

    txSetColor     (RGB (128, 0, 128));
    txSetFillColor (RGB (128, 0, 128));
    txCircle       (1310, 440, 30);

    txSetColor     (RGB (101, 88, 116), 4);
    txSetFillColor (RGB (125, 109, 146));
    txCircle       (1310, 610, 50);

    txSetColor     (RGB (101, 88, 116));
    txSetFillColor (RGB (101, 88, 116));
    txRectangle    (1300, 580, 1320, 640);

    txSetColor     (TX_BLACK, 5);
    txSelectFont   ("Arial", 40, 0, FW_BOLD);
    txDrawText     (1210,  700, 1390, 750, " ��������");

    txSetColor     (RGB (128, 255, 255), 10);
    txSetFillColor (RGB (128, 255, 255));
    txRectangle    (20, 20, 1210, 785);
    }
