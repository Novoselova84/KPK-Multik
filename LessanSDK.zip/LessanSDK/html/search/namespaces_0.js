var searchData=
[
  ['lessan_32',['Lessan',['../namespace_lessan.html',1,'']]]
];
