var searchData=
[
  ['sleeptime_63',['SleepTime',['../_example__1_8cpp.html#a5929ef3843a6476fc40a70f9ad522439',1,'SleepTime():&#160;Example_1.cpp'],['../_example__3_8cpp.html#a5929ef3843a6476fc40a70f9ad522439',1,'SleepTime():&#160;Example_3.cpp'],['../namespace_lessan.html#af2b85961aa504045d8aec1e707117b0a',1,'Lessan::SleepTime()']]]
];
