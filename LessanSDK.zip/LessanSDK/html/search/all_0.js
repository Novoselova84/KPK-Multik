var searchData=
[
  ['author_0',['Author',['../_novoselova___olessya___multik_8cpp.html#ac61b7935e9303aca9033ce95c199938d',1,'Novoselova_Olessya_Multik.cpp']]]
];
