var searchData=
[
  ['enjoyment_53',['Enjoyment',['../_novoselova___olessya___multik_8cpp.html#aff8f1c483ed64edbe57a9f4c23aee5ca',1,'Novoselova_Olessya_Multik.cpp']]]
];
